/*
 *Copyright (c) 2009-2018, Ioannis Vasilopoulos
 *All rights reserved.
 *
 *Redistribution and use in source and binary forms, with or without
 *modification, are permitted provided that the following conditions are met:
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *    * Neither the name of Koios nor the
 *      names of its contributors may be used to endorse or promote products
 *      derived from this software without specific prior written permission.
 *
 *THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 *ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 *WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
 *DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 *(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 *SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

package org.coeus.wizards;

import org.coeus.parsers.parserDefinitions;


public class Messages {

    public static final String ERR_CON_NAME_BL1="The name of a CONSTANT cannot be blank!"; 
    public static final String ERR_CON_NAME_BL2="Enter a name in the field \"Name\".";
    public static final String ERR_CON_NAME_LET1="The name of a CONSTANT must begin with a letter, or a dollar sign($) or an underscore(_)!";
    public static final String ERR_CON_NAME_LET2="Correct the name in the field \"Name\".";
    public static final String ERR_CON_NAME_LET3="The name of  a CONSTANT must contain one or more characters. Each character can be a letter or a number or a dollar sign($)and or an underscore(_)!";
    public static final String ERR_CON_NAME_RES="The name that you have entered is already used for other purposes (reserved word) and cannot be used!";
    public static final String ERR_CON_NAME_USE="The name that you have entered is already used for ";
    public static final String ERR_CON_NAME_USE1="within the scope of ";
    public static final String ERR_CON_NAME_USE2="with scope: ";
    public static final String ERR_CON_VALUE_EM1="The initial value of a CONSTANT cannot be blank!";
    public static final String ERR_CON_VALUE_EM2="While declaring a CONSTANT, an initial value must be assigned to it!";
    public static final String ERR_CON_VALUE_NUM1="The value of an INTEGER CONSTANT must contain only numbers!";
    public static final String ERR_CON_VALUE_NUM2="Correct the value in the field \"Initial Value\".";
    public static final String ERR_CON_VALUE_OOL1="The value of an INTEGER CONSTANT must be between "+ Integer.MIN_VALUE + " and "+Integer.MAX_VALUE+"!";
    public static final String ERR_CON_VALUE_OOL2="The integer part of a REAL CONSTANT must contain only numbers!";
    public static final String ERR_CON_VALUE_OOL3="The decimal part of a REAL CONSTANT must contain only numbers!";
    public static final String ERR_CON_VALUE_OOL4="The value of a CHARACTER CONSTANT must contain only one character!";
    public static final String ERR_CON_VALUE_OOL4A="You have entered  ";
    public static final String ERR_CON_VALUE_OOL4B=" characters.";
    public static final String ERR_CON_VALUE_OOL5="The value of a REAL CONSTANT must be between "+ Float.MIN_VALUE + " and "+Float.MAX_VALUE+"!";
    public static final String ERR_CON_NAME_PARM1=" the input parameter no";
    public static final String ERR_CON_NAME_PARM2=" of ";

    public static final String INFO_CON1a="A CONSTANT of ";
    public static final String INFO_CON1b="A CONSTANT of ";
    public static final String INFO_CON2=" type, with name " ; ;
    public static final String INFO_CON3=" and initial value ";
    public static final String INFO_CON4a=" was created. ";
    public static final String INFO_CON4b=" was updated. ";

    public static final String INFO_CON_PANEL1="Prefer uppercase letters for the name of the CONSTANT.";
    public static final String INFO_CON_PANEL2="Enter the initial value of the CONSTANT in the field \"Initial Value\".";

    //////////////VARIABLES///////////////
    public static final String ERR_VAR_NAME_BL1="The name of a VARIABLE cannot be blank!";
    public static final String ERR_VAR_NAME_BL2="Enter a name in the field \"Name\".";
    public static final String ERR_VAR_NAME_LET1=" The name of a VARIABLE must begin with a letter, or a dollar sign($) or an underscore(_)!";
    public static final String ERR_VAR_NAME_LET2="Correct the name in the field \"Name\".";
    public static final String ERR_VAR_NAME_LET3= "The name of  a VARIABLE must contain one or more characters. Each character can be a letter or a number or a dollar sign($)and or an underscore(_)"; 
    public static final String ERR_VAR_NAME_RES="The name that you have entered is already used for other purposes (reserved word) and cannot be used!";
    public static final String ERR_VAR_NAME_USE="The name that you have entered is already used for ";
    public static final String ERR_VAR_NAME_USE1="within the scope of ";
    public static final String ERR_VAR_NAME_USE2="with scope: ";
    public static final String ERR_VAR_VALUE_EM1="The initial value of a VARIABLE cannot be blank!";
    public static final String ERR_VAR_VALUE_EM2= "You have selected to assign an initial value to this VARIABLE!\nIf you prefer not to assign an initial value to this VARIABLE, select  \"Variable without Initial Value\"";
    public static final String ERR_VAR_VALUE_NUM1="The value of an INTEGER VARIABLE must contain numbers only!";
    public static final String ERR_VAR_VALUE_NUM2="Correct the value in the field \"Initial Value\".";
    public static final String ERR_VAR_VALUE_OOL1="The value of an INTEGER VARIABLE must be between "+ Integer.MIN_VALUE + " and "+Integer.MAX_VALUE+"!";
    public static final String ERR_VAR_VALUE_OOL2="The integer part of a REAL VARIABLE must contain only numbers!";
    public static final String ERR_VAR_VALUE_OOL3="The decimal part of a REAL VARIABLE must contain only numbers!";
    public static final String ERR_VAR_VALUE_OOL4="The value of a CHARACTER VARIABLE must contain only one character!";
    public static final String ERR_VAR_VALUE_OOL4A="You have entered  ";
    public static final String ERR_VAR_VALUE_OOL4B=" characters";
    public static final String ERR_VAR_VALUE_OOL5="The value of a REAL VARIABLE must be between "+ Float.MIN_VALUE + " and "+Float.MAX_VALUE+"!";
    public static final String ERR_VAR_NAME_PARM1=" the input parameter no";
    public static final String ERR_VAR_NAME_PARM2=" of ";

    public static final String INFO_VAR1a="A VARIABLE of ";
    public static final String INFO_VAR1b="A VARIABLE of ";
    public static final String INFO_VAR2=" type, with name " ;
    public static final String INFO_VAR3=" and initial value ";
    public static final String INFO_VAR4=" but without initial value";
    public static final String INFO_VAR5a=" was created. ";
    public static final String INFO_VAR5b=" was updated. ";

    public static final String INFO_VAR_PANEL1="Prefer uppercase letters for the name of the VARIABLE.";
    public static final String INFO_VAR_PANEL2="Enter the initial value of the VARIABLE in the field \"Initial Value\".";

    //////////////ARRAYS///////////////
    public static final String ERR_ARR_NAME_BL1="The name of an ARRAY cannot be blank!";
    public static final String ERR_ARR_NAME_BL2="Enter a name in the field \"Name\".";
    public static final String ERR_ARR_NAME_LET1=" The name of an ARRAY must begin with a letter, or a dollar sign($) or an underscore(_)!";
    public static final String ERR_ARR_NAME_LET2="Correct the name in the field \"Name\".";
    public static final String ERR_ARR_NAME_LET3="The name of  an ARRAY must contain one or more characters. Each character can be a letter or a number or a dollar sign($)and or an underscore(_)";
    public static final String ERR_ARR_NAME_RES="The name that you have entered is already used for other purposes (reserved word) and cannot be used!";
    public static final String ERR_ARR_NAME_USE="The name that you have entered is already used for ";
    public static final String ERR_ARR_NAME_USE1="within the scope of ";
    public static final String ERR_ARR_NAME_USE2="with scope: ";
    public static final String ERR_ARR_VALUE_EM1="The initial values of an ARRAY cannot be blank!";
    public static final String ERR_ARR_VALUE_EM2=" You have selected to assign initial values to this ARRAY!\nIf you prefer not to assign initial values to this ARRAY, select  \"Array without Initial Value\"";
    public static final String ERR_ARR_VALUE_NUM1="The values of an INTEGER ARRAY must be INTEGER only numbers!";
    public static final String ERR_ARR_VALUE_OOL1="The values of an INTEGER ARRAY must be between "+ Integer.MIN_VALUE + " and "+Integer.MAX_VALUE+" !";
    public static final String ERR_ARR_VALUE_OOL2="The values of a REAL ARRAY must be only REAL numbers!";
    public static final String ERR_ARR_VALUE_OOL3="Each value of a REAL ARRAY must contain only one decimal point  \".\"";
    public static final String ERR_ARR_VALUE_OOL4="Each value of a CHARACTER ARRAY must contain only one character!";
    public static final String ERR_ARR_VALUE_OOL4A="You have entered  ";
    public static final String ERR_ARR_VALUE_OOL4B=" characters";
    public static final String ERR_ARR_VALUE_OOL5="The values of a REAL ARRAY must be between "+ Float.MIN_VALUE + " and "+Float.MAX_VALUE+" !";
    public static final String ERR_ARR_DIM1_EM="The size of the 1st Dimension of the ARRAY cannot be blank!";
    public static final String ERR_ARR_VALUE_BOOL1="The values of a BOOLEAN ARRAY must be \""+parserDefinitions.TRUE+"\" or \""+parserDefinitions.FALSE+"\".";
    public static final String ERR_ARR_VALUE_BOOL2="Correct the value of the ARRAY Element in position ";
    public static final String ERR_ARR_DIM1_INT="The size of the 1st Dimension of the ARRAY must be an integer and greater than 1.";
    public static final String ERR_ARR_DIM1_EM1="Correct the value in the field \"Size of 1st Dimension\".";
    public static final String ERR_ARR_DIM2_EM="The size of the 2nd Dimension of the ARRAY cannot be blank!";
    public static final String ERR_ARR_DIM2_INT="The size of the 2nd Dimension of a two-dimensional ARRAY must be an integer and greater than 1.";
    public static final String ERR_ARR_DIM2_EM1="Correct the value in the field \"Size of 1st Dimension\".";
    public static final String ERR_ARR_NAME_PARM1=" the input parameter no";
    public static final String ERR_ARR_NAME_PARM2=" of ";

    public static final String INFO_ARR1a="An ARRAY of ";
    public static final String INFO_ARR1b="An ARRAY of ";
    public static final String INFO_ARR2=" type, with name " ;
    public static final String INFO_ARR3=" and initial values ";
    public static final String INFO_ARR4=" but without initial values";
    public static final String INFO_ARR5a=" was created. ";
    public static final String INFO_ARR5b=" was updated. ";

    public static final String INFO_ARR_PANEL1="Prefer uppercase letters for the name of the ARRAY.";
    public static final String INFO_ARR_PANEL2="Enter the initial values of the ARRAY.After entering each value, press ENTER or click on a different cell.";

    /////////////FUNCTIONS/////////////////
    public static final String ERR_FUN_NAME_BL1="The name of a FUNCTION cannot be blank!";
    public static final String ERR_FUN_NAME_BL2="Enter a name in the field \"Name\".";
    public static final String ERR_FUN_NAME_LET1="The name of a FUNCTION must begin with a letter, or a dollar sign($) or an underscore(_)!";
    public static final String ERR_FUN_NAME_LET2="Correct the name in the field \"Name\".";
    public static final String ERR_FUN_NAME_LET3="The name of  a FUNCTION must contain one or more characters. Each character can be a letter or a number or a dollar sign($) and or an underscore(_)!";
    public static final String ERR_FUN_NAME_RES="The name that you have entered is already used for other purposes (reserved word) and cannot be used!";
    public static final String ERR_FUN_NAME_USE="The name that you have entered is already used for ";
    public static final String ERR_FUN_NAME_USE1="\n";
    public static final String ERR_FUN_ARGUEMENT_EM1="The name of a formal parameter cannot be blank!";
    public static final String ERR_FUN_ARGUEMENT_EM2="Enter the name in the field  \"Name\" of ";
    public static final String ERR_FUN_ARGUEMENT_LET1="The name of a formal input parameter must begin with a letter, or a dollar sign($) or an underscore(_)!";
    public static final String ERR_FUN_ARGUEMENT_LET2a="Modify";
    public static final String ERR_FUN_ARGUEMENT_LET2b=" and correct its name in the field \"Name\".";
    public static final String ERR_FUN_ARGUEMENT_LET3="The name of a formal input parameter must contain one or more characters. Each character can be a letter or a number or a dollar sign($) and or an underscore(_)!";
    public static final String ERR_FUN_ARGUEMENT_RES="The name that you have entered is already used for other purposes (reserved word) and cannot be used!";
    public static final String ERR_FUN_ARGUEMENT_USE="The name that you have entered is already used for ";
    public static final String ERR_FUN_ARGUEMENT_USE1="The name that you have entered is already used as the name of this FUNCTION! ";
    public static final String ERR_FUN_ARGUEMENT_USE2="The name that you have entered is already used for ";
    public static final String ERR_FUN_ARGUEMENT_UPDTAE_CANCELED="\nThe update of this parameter was cancelled!";

    public static final String INFO_FUN1a="A FUNCTION of ";
    public static final String INFO_FUN1b="A FUNCTION of ";
    public static final String INFO_FUN2=" type, with name " ;
    public static final String INFO_FUN3=" and formal input parameter(s):";
    public static final String INFO_FUN4=" without formal input parameters ";
    public static final String INFO_FUN5a="was created. ";
    public static final String INFO_FUN5b="was updated. ";
    public static final String INFO_FUN_PANEL1="Prefer uppercase letters for the name of the FUNCTION ";
    public static final String INFO_FUN_PANEL2="Enter the name(s) and type(s) of the formal input parameter(s) ";

    /////////////PROCEDURES/////////////////
    public static final String ERR_PRO_NAME_BL1="The name of a PROCEDURE cannot be blank!";
    public static final String ERR_PRO_NAME_BL2="Enter a name in the field \"Name\".";
    public static final String ERR_PRO_NAME_LET1="The name of a PROCEDURE must begin with a letter, or a dollar sign($) or an underscore(_)!";
    public static final String ERR_PRO_NAME_LET2="Correct the name in the field \"Name\".";
    public static final String ERR_PRO_NAME_LET3="The name of  a PROCEDURE must contain one or more characters. Each character can be a letter or a number or a dollar sign($) and or an underscore(_)!";
    public static final String ERR_PRO_NAME_RES="The name that you have entered is already used for other purposes (reserved word) and cannot be used!";
    public static final String ERR_PRO_NAME_USE="The name that you have entered is already used for ";
    public static final String ERR_PRO_NAME_USE1="\n";
    public static final String ERR_PRO_ARGUEMENT_EM1="The name of a formal parameter cannot be blank!";
    public static final String ERR_PRO_ARGUEMENT_EM2="Enter the name in the field \"Name\" of ";
    public static final String ERR_PRO_ARGUEMENT_LET1="The name of a formal input parameter must begin with a letter, or a dollar sign($) or an underscore(_)!";
    public static final String ERR_PRO_ARGUEMENT_LET2a="Modify";
    public static final String ERR_PRO_ARGUEMENT_LET2b=" and correct its name in the field \"Name\".";
    public static final String ERR_PRO_ARGUEMENT_LET3="The name of a formal input parameter must contain one or more characters. Each character can be a letter or a number or a dollar sign($) and or an underscore(_)!";
    public static final String ERR_PRO_ARGUEMENT_RES="The name that you have entered is already used for other purposes (reserved word) and cannot be used!";
    public static final String ERR_PRO_ARGUEMENT_USE="The name that you have entered is already used for ";
    public static final String ERR_PRO_ARGUEMENT_USE1="The name that you have entered is already used as the name of this PROCEDURE! ";
    public static final String ERR_PRO_ARGUEMENT_USE2="The name that you have entered is already used for ";
    public static final String ERR_PRO_ARGUEMENT_UPDTAE_CANCELED="\nThe update of this parameter was cancelled!";
    public static final String INFO_PRO1a="A PROCEDURE ";
    public static final String INFO_PRO1b="A PROCEDURE ";
    public static final String INFO_PRO2="with name " ;
    public static final String INFO_PRO3=" and formal input parameter(s):";
    public static final String INFO_PRO4=" without formal input parameters ";
    public static final String INFO_PRO5a="was created. ";
    public static final String INFO_PRO5b="was updated. ";

    public static final String INFO_PRO_PANEL1="Prefer uppercase letters for the name of the PROCEDURE ";
    public static final String INFO_PRO_PANEL2="Enter the name(s) and type(s) of the formal input parameter(s) ";

 ///////////READ//////////////////
    public static final String INFO_READ_PANEL1="";
    public static final String INFO_READ1a=" A \"READ\" command was created!\nDuring execution, the user will be asked to enter ";
    public static final String INFO_READ1b=" A \"READ\" command was updated!\nDuring execution, the user will be asked to enter ";
    public static final String INFO_READ2=" value(s),\nwhich will be stored in the following item(s): \n";

    public static final String ERR_READ_EMPTY="There are no arguments for this \"READ\" command!\nAdd at least one argument in this command!"; 

    ///////////WRITE//////////////////
    public static final String INFO_WRITE_PANEL1="";
    public static final String INFO_WRITE1a=" A \"WRITE\" command was created!\nMessage(s) and \\or value(s) of the following  ";
    public static final String INFO_WRITE1b=" A \"WRITE\" command was updated!\nMessage(s) and \\or value(s) of the following ";
    public static final String INFO_WRITE2=" item(s) will be shown on the Output Window: \n";

    public static final String ERR_WRITE_EMPTY="Δεν έχετε εισάγει κανένα στοιχείο!\nΠροσθέστε τουλάχιστον ενα στοιχείο στην εντολή ΔΙΑΒΑΣΕ!";
 ///////////CALL//////////////////
    public static final String INFO_CALL_PANEL1="Select which PROCEDURE you want to call";
    public static final String INFO_CALL1a="A \"CALL\" command was created!\nThis command will call the PROCEDURE ";
    public static final String INFO_CALL1b="A \"CALL\" command was updated!\nThis command will call the PROCEDURE ";
    public static final String INFO_CALL2=" with the following as actual input parameters: \n";

    public static final String ERR_CALL_EMPTY="There are no arguments for this \"CALL\" command!\nAdd at least one argument in this command!"; 

    public static final String INFO_FUNCCALL_PANEL1="Select which FUNCTION you want to call";

  //////////////ASSIGN////////////////////
    public static final String INFO_ASSIGN_PANEL1="Select where you want to store the value that you will enter ";
    public static final String INFO_ASSIGN1a="An \"ASSIGN\" command was created!\nThis command will assign to ";
    public static final String INFO_ASSIGN1b="An \"ASSIGN\" command was updated!\nThis command will assign to ";
    public static final String INFO_ASSIGN2=" the ";


////////////RETURN/////////////////
    public static final String INFO_RETURN_PANEL1="Enter the expression that will be returned by this FUNCTION ";
    public static final String INFO_RETURN1a="A \"RETURN\" command was created!\nFUNCTION ";
    public static final String INFO_RETURN1b="A \"RETURN\" command was created!\nFUNCTION ";
    public static final String INFO_RETURN2=" will use this command to return the\n";

////////////WHILE/////////////////
    public static final String INFO_WHILE_PANEL1="Enter the LOGICAL CONDITION for this iteration statement.";
    public static final String INFO_WHILE_PANEL2=" command ";
    public static final String INFO_WHILE1=" A \"";
    public static final String INFO_WHILE2a="\" iteration statement was created!\nWhile the LOGIC CONDITION ";
    public static final String INFO_WHILE2b="\" iteration statement was updated!\nWhile the LOGIC CONDITION ";
    public static final String INFO_WHILE3=" is valid,\nthe command(s) in this iteration statement will be executed repeatedly.";
    public static final String INFO_DOWHILE2a="\" was created!\nThe command(s) in this iteration statement will be executed once.\nThen, while the LOGIC CONDITION ";
    public static final String INFO_DOWHILE2b="\" was updated!\nThe command(s) in this iteration statement will be executed once.\nThen, while the LOGIC CONDITION ";

    ////////////FOR/////////////////
    public static final String INFO_FOR_PANEL1="Enter the INITIAL EXPRESSION, the FINAL CONDITION and the STEP for this iteration statement ";
    public static final String INFO_FOR1a="A \"FOR..LOOP\" iteration statement was created!\nThe INITIAL EXPRESSION is ";
    public static final String INFO_FOR1b="A \"FOR..LOOP\" iteration statement was updated!\nThe INITIAL EXPRESSION is ";
    public static final String INFO_FOR2=",\nthe FINAL CONDITION is ";
    public static final String INFO_FOR3="\nand the STEP is ";
    public static final String INFO_FOR4=".";
    ////////////IF/////////////////
    public static final String INFO_IF_PANEL1="Enter the condition(s) for the IF statement and optionally for the ELSE IF statement(s) ";
    public static final String INFO_IF1a="An \"IF..ELSE\" conditional statement was created!\nIt contains the following statements and conditions:\n" ;
    public static final String INFO_IF1b="An \"IF..ELSE\" conditional statement was updated!\nIt contains the following statements and conditions:\n" ;
    public static final String INFO_IF2="\nThe command(s) in each statement will be executed if the condition of this statement is valid and all the statements before it are not valid.";

    public static final String ERR_ASS_EMPTY="No selections have been made for the \"ASSIGN\" command!\nMake a selection to assign a value or click CANCEL.";

}
